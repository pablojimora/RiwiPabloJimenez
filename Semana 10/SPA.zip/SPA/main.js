import { get, post } from './services.js';

const urlUsers= 'http://localhost:3000/users';

const routes = {
    '/': './views/users.html',
    '/users': './views/users.html',
    '/newuser': './views/newUsers.html',
    '/about': './views/about.html',
    '/login': './views/login.html',
};

let counter = 0;


function isAuth() {
    let result = localStorage.getItem('Auth') || null
    const resultBool = result === 'true'
    return resultBool;
}


async function navigate(pathname) {
    // Verifica si el usuario está autenticado para permitir la entrada a las vistas
    if (!isAuth()) {
        pathname = '/login';
    }

    const route = routes[pathname];
    const html = await fetch(route).then(res => res.text());
    document.getElementById('content').innerHTML = html;
    history.pushState({}, '', pathname);
    // Verifica si la ruta es '/about' para ejecutar la función de contador
    //Y asi debo llamar a cada funcion de las diferentes vistas
    if (pathname === '/about') {
        functionCount();
    }
    if (pathname === "/login") {
        setupLoginForm()
    };
    if (pathname === '/users') {
        showUsers();
    }
    if (pathname === '/newuser') {
        addUser();
    }

};

//Debo comenzar a escuchar eventos para capturar las funciones por medio de los botones

document.body.addEventListener('click', (e) => {
    if (e.target.matches("[data-link]")) {
        //Estas lineas son para evitar que el navegador recargue la pagina
        e.preventDefault();
        //Esta linea es para navegar a la ruta que se le pasa como parametro
        const path = e.target.getAttribute('href');
        navigate(path);
    }
});

function functionCount() {
    const counterValue = document.getElementById('counter-value');
    const incrementBtn = document.getElementById('increment-btn');
    const decrementBtn = document.getElementById('decrement-btn');

    incrementBtn.addEventListener("click", () => {
        counter++;
        counterValue.textContent = counter;
    });
    decrementBtn.addEventListener("click", () => {
        counter--;
        counterValue.textContent = counter;
    });
};

// Esta funcion sirve para devolverme a la pagina anterior
window.addEventListener("popstate", () => {
    console.log("se hizo clic");
    console.log(location);
    navigate(location.pathname);
});


//funcion del  login 
function setupLoginForm() {
    const userAuth = "admin";
    const passAuth = "1234";

    const form = document.getElementById("login-spa");

    form.addEventListener("submit", (e) => {
        e.preventDefault();

        const user = document.getElementById("user").value;
        const pass = document.getElementById("password").value;

        if (user === userAuth && pass === passAuth) {
            localStorage.setItem("Auth", "true");
            navigate("/users");
        } else {
            alert("usuario o contraseña son incorrectos");
        }
    });
}

//Funcion para cerrar sesion 
const buttonCloseSession = document.getElementById("close-sesion");
buttonCloseSession.addEventListener("click", () => {
    localStorage.setItem("Auth", "false");
    navigate("/login");
});


window.addEventListener("DOMContentLoaded", () => {
    navigate(location.pathname);
});

//Funcion para mostrar usuarios

function showUsers() {
    let containerUsers = document.getElementById("container-users");

    let userData = get(urlUsers)
    
    userData.then((data) => {
        data.forEach(user => {
            let userElement = document.createElement("div");
            userElement.className = "user";
            userElement.innerHTML = `
                <div>
                <h3>${user.name}</h3>
                <p>Email: ${user.email}</p>
                <p>Phone: ${user.phone}</p>
                <p>Enrollment Number: ${user.enrollNumber}</p>
                <p>Date of Admission: ${user.dateOfAdmission}</p>
                </div>
            `;
            containerUsers.appendChild(userElement);
        });
    }).catch(error => {
        console.error("Error fetching users:", error);
    });
};

//Funcion para agregar usuarios
function addUser() {
    const form = document.getElementById("new-user-form");
    form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const name = document.getElementById("name").value;
        const email = document.getElementById("email").value;
        const phone = document.getElementById("phone").value;
        const enrollNumber = document.getElementById("enrollNumber").value;
        const dateOfAdmission = document.getElementById("dateOfAdmission").value;

        const newUser = {
            name,
            email,
            phone,
            enrollNumber,
            dateOfAdmission
        };

        try {
            await post(urlUsers, newUser);
            alert("Usuario agregado correctamente");
            navigate("/users");
        } catch (error) {
            console.error("Error adding user:", error);
        }
    });
}

//Funcion para actualizar usuarios

